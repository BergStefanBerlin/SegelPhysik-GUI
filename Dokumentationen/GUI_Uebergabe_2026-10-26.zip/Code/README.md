# SegelPhysik-Core: nativer Build

Eigenständige C++17-Bibliothek und CLI ohne Python, pybind11 oder GUI.
Implementiert sind Modellimport/-prüfung, Massenintegration,
Wasserebenenschnitt, gemeinsame Hydrostatik, statisches Gleichgewicht,
Starrkörperdynamik, Aufzeichnung und abfragbarer JSON-Fehlerkatalog.
Es gelten die ausdrücklich dokumentierten
[numerischen und geometrischen Grenzen](../Dokumentationen/Umsetzungsnachweise_Hydrostatikkern.md).

## Bauen und prüfen

Mit CMake ab 3.20 und einem C++17-Compiler, vom Repository aus:

```powershell
cmake -S Code -B build\standard -DBUILD_TESTING=ON
cmake --build build\standard --config Release
ctest --test-dir build\standard -C Release --output-on-failure
.\build\standard\Release\segelphysik_cli.exe --build-info
```

Die Beispielpfade zur EXE gelten für Visual Studio als
Mehrkonfigurationsgenerator. Bei Einkonfigurationsgeneratoren wird
`-DCMAKE_BUILD_TYPE=Release` beim Konfigurieren benötigt und die EXE
liegt direkt im Buildverzeichnis.

Für den Build ohne Testprogramme `-DBUILD_TESTING=OFF` verwenden.
Die Option `-DSEGELPHYSIK_TEST_INSTRUMENTATION=ON` bereitet einen
gesonderten Testbuild vor und erfordert `BUILD_TESTING=ON`.
Detailtimer benötigen zusätzlich `testmessungen_aktivieren(true)`.
Die CLI aktiviert sie nicht; die Gesamtlaufzeitmessung ist immer aktiv.
Die [Messliste](../Dokumentationen/Zeitmessungen.md) beschreibt Grenzen,
Verschachtelungen und zugehörige Tests.

## CLI und Bibliothek

Die CLI unterstützt `--help`, `--build-info`, `--fehlerdoku`,
`--pruefen MODELL`, `--statisch MODELL AUSGABE` und
`--dynamisch MODELL AUSGABE DAUER_S DT_S`.
`--fehlerdoku` gibt den eingebetteten
[Fehlerkatalog](ressourcen/fehlerkatalog.json) als UTF-8-JSON aus,
ohne ein Modell zu laden. Der Katalog beschreibt die tatsächlich
implementierten Prüfungen innerhalb ihrer dokumentierten Grenzen.
Der [Ergebnis-/Fehlervertrag](../Dokumentationen/Schnittstelle_Core_GUI.md)
beschreibt die fachliche Anfrage „gib mir Fehlerdoku“ und ihren aktuellen
CLI-Abfrageweg; eine Live-Verbindung ist noch nicht implementiert.
Fehlende, zusätzliche oder unbekannte Argumente führen zu Exitcode 2
und einer Fehlermeldung auf stderr. Tests prüfen auch diese Fehlerpfade.

Beispiele, vom Repository aus (Ausgabedateien dürfen noch nicht existieren):

```powershell
$cli = ".\build\standard\Release\segelphysik_cli.exe"
$modell = ".\Spezifikationen\Beispiele_Modellformat\modelle\quader\modell.json"
& $cli --pruefen $modell
& $cli --statisch $modell ".\build\statik.json"
& $cli --dynamisch $modell ".\build\dynamik.jsonl" 1 0.01
```

`.jsonl` liefert vollständige Zustände pro Zeile, andere Endungen ein
inkrementell geschriebenes JSON-Array. Laufstatus und Gesamtdauer
erscheinen auf stdout, Diagnosen auf stderr. Ein Modellprüfaufruf
liefert dagegen ein strukturiertes JSON-Prüfergebnis.
Ctrl+C fordert den Abbruch laufender Simulationen an.
Erfolg: Exitcode 0; abgelehnte Modelle, Solverfehler oder Abbruch:
Exitcode 1; falsche CLI-Verwendung: Exitcode 2.

Die Bibliotheks-API steht in [modell.hpp](include/segelphysik/modell.hpp),
[hydrostatik.hpp](include/segelphysik/hydrostatik.hpp) und
[simulation.hpp](include/segelphysik/simulation.hpp).
Vorbereitete Modelle können für wiederholte Auswertungen und Schritte
wiederverwendet werden, ohne Dateien pro Schritt neu einzulesen.

## Reproduzierbare Benchmarks

`core_benchmark MODELL` misst ohne GUI und ohne aktive Detailtimer.
Der optionale Python-Standardbibliotheks-Treiber benötigt keine Pakete:

```powershell
python Code\tests\benchmark_suite.py build\standard\Release build\performance.json
```

Er erzeugt kleine, zusammengesetzte und große Referenzläufe, prüft deren
JSON-Ausgaben und berichtet Aufwärmung, Wiederholungen, Median und
Streuung. Python wird nur für diese Teststeuerung verwendet, nicht
für Build oder produktive Berechnungen.

Der [Umsetzungsplan](../Umsetzungsplaene/Umsetzungsplan_Hydrostatikkern.md)
enthält Umfang, Abhängigkeiten und tatsächlichen Fortschritt.
